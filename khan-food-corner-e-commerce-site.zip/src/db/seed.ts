import { count, sql } from "drizzle-orm";
import { db } from "./index";
import { generateReviews, px, seedProducts } from "./seed-data";
import { products, reviews } from "./schema";

let seeding: Promise<void> | null = null;

async function run() {
  await db.transaction(async (tx) => {
    // Serialise concurrent seeders across processes.
    await tx.execute(sql`select pg_advisory_xact_lock(884422)`);
    const [{ value }] = await tx.select({ value: count() }).from(products);
    if (value > 0) return;

    for (let i = 0; i < seedProducts.length; i++) {
      const p = seedProducts[i];
      await tx
        .insert(products)
        .values({
          slug: p.slug,
          name: p.name,
          tagline: p.tagline,
          description: p.description,
          category: p.category,
          price: p.price,
          comparePrice: p.comparePrice ?? null,
          images: p.images.map((id) => px(id)),
          variants: p.variants ?? [],
          highlights: p.highlights,
          spice: p.spice,
          isFeatured: !!p.featured,
          isBestseller: !!p.bestseller,
          isNew: !!p.isNew,
          prepMinutes: p.prep,
          serves: p.serves,
          calories: p.calories ?? null,
          sortOrder: i,
        })
        .onConflictDoNothing();
    }

    const rows = await tx.select({ id: products.id, slug: products.slug }).from(products);
    const idBySlug = new Map(rows.map((r) => [r.slug, r.id]));
    const now = Date.now();
    const toInsert = generateReviews()
      .filter((r) => idBySlug.has(r.slug))
      .map((r) => ({
        productId: idBySlug.get(r.slug)!,
        author: r.author,
        area: r.area,
        rating: r.rating,
        title: r.title,
        body: r.body,
        verified: r.verified,
        createdAt: new Date(now - r.daysAgo * 86_400_000),
      }));
    if (toInsert.length) await tx.insert(reviews).values(toInsert);
  });
}

/** Seeds demo catalogue + reviews the first time the shop is opened (idempotent). */
export function ensureSeeded(): Promise<void> {
  if (!seeding) {
    seeding = run().catch((err) => {
      seeding = null;
      throw err;
    });
  }
  return seeding;
}
